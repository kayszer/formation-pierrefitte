# Intégration

Intégration de la maquette du restaurant *Ce soir*
![maquette]('maquette.jpg')

mettre en place une hierarchie de dossier correcte.
La liste est exaustive, n'utiliser que ce qui vous est necessaire.

  projet >
    [img]>
    [css]>
      style.css
    [elements]>
      jQuery
      autre
    [js]
    index

Vous trouverez des textures pour le background du header ici :
  [cg_texture]('http://www.textures.com/browse/bare/45356')


* Les images sont dans le dossier img. A ré-aranger dans la hierarchie.
* Pour le log vous utiliserez le fichier cerf.svg

Bon travail !
